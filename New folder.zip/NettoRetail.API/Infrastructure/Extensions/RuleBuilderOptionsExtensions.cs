﻿using System.Text.RegularExpressions;
using FluentValidation;
using NettoRetail.Domain.Enums;

namespace NettoRetail.API.Infrastructure.Extensions;

public static class RuleBuilderOptionsExtensions
{
    public static IRuleBuilderOptions<T, string?> MustBeAValidInventoryItemStatus<T>(this IRuleBuilder<T, string?> ruleBuilder)
    {
        return ruleBuilder.Must(status =>
        {
            if (string.IsNullOrEmpty(status))
                return true;

            return Enum.TryParse(typeof(InventoryItemStatusEnum), status, true, out _);
        });
    }

    public static IRuleBuilderOptions<T, string?> MustBeAValidUrl<T>(this IRuleBuilder<T, string?> ruleBuilder)
    {
        return ruleBuilder.Must(url =>
        {
            return Uri.TryCreate(url, UriKind.Absolute, out var uriResult)
                   && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
        });
    }

    public static IRuleBuilderOptions<T, string> MustHaveImageExtension<T>(this IRuleBuilder<T, string> ruleBuilder)
    {
        return ruleBuilder.Must(filename =>
        {
            string[] permittedExtensions = [".jpg", ".jpeg", ".png"];
            var extension = Path.GetExtension(filename).ToLowerInvariant();
            return permittedExtensions.Contains(extension);
        });
    }

    public static IRuleBuilderOptions<T, string?> MustBeAValidOrderStatus<T>(this IRuleBuilder<T, string?> ruleBuilder)
    {
        return ruleBuilder.Must(status =>
        {
            return string.IsNullOrWhiteSpace(status) || Enum.TryParse(typeof(OrderStatusEnum), status, true, out _);
        });
    }

    public static IRuleBuilderOptions<T, string?> MustBeAValidAccountStatus<T>(this IRuleBuilder<T, string?> ruleBuilder)
    {
        return ruleBuilder.Must(status =>
        {
            return string.IsNullOrWhiteSpace(status) || Enum.TryParse(typeof(StaffStatusEnum), status, true, out _);
        });
    }

    public static IRuleBuilderOptions<T, string?> MustBeAValidOrderDeliveryType<T>(this IRuleBuilder<T, string?> ruleBuilder)
    {
        return ruleBuilder.Must(type =>
        {
            return string.IsNullOrWhiteSpace(type) || Enum.TryParse(typeof(OrderDeliveryTypeEnum), type, true, out _);
        });
    }
}
