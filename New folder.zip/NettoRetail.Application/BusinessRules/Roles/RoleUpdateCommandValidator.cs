﻿using FluentValidation;
using NettoRetail.Application.CQRS.Roles.Commands;
using NettoRetail.Application.Exceptions;
using NettoRetail.DataAccess.Specifications.Permissions;
using NettoRetail.DataAccess.Specifications.Role;
using NettoRetail.DataAccess.Specifications.Shop;
using NettoRetail.Shared.Constants;
using NettoRetail.Shared.Interfaces.Repositories;
using NettoRetail.Shared.Security;

namespace NettoRetail.Application.BusinessRules.Roles;

public class RoleUpdateCommandValidator : AbstractValidator<RoleUpdateCommand>
{
    public RoleUpdateCommandValidator(IRoleRepository roleRepository, IShopRepository shopRepository, IPermissionRepository permissionRepository)
    {
        RuleFor(x => x.Id)
            .Custom((roleId, context) =>
            {
                if (roleId == RoleConstants.Admin)
                    throw new ConflictException(ValidationErrorMessages.Role.CannotEditAdminRoleErrorMessage);
            });

        // Shop existence validation
        RuleFor(x => x.ShopId)
            .CustomAsync(async (shopId, context, ct) =>
            {
                var exists = await shopRepository.ExistsAsync(new GetShopByIdSpecification(shopId), ct);

                if (!exists)
                    throw new NotFoundException(string.Format(ValidationErrorMessages.Shop.ShopDoesntExistErrorMessage,  shopId));
            });

        // Role existence validation
        RuleFor(x => x)
            .CustomAsync(async (command, context, ct) =>
            {
                var exists = await roleRepository.ExistsAsync(
                    new GetRoleByIdAndShopIdSpecification(
                        command.Id,
                        command.ShopId),
                    ct);

                if (!exists)
                    throw new NotFoundException(string.Format(ValidationErrorMessages.Role.RoleNotFoundWithShopIdErrorMessage, command.Id, command.ShopId));
            });

        // Unique role name validation
        RuleFor(x => x)
            .CustomAsync(async (command, context, ct) =>
            {
                var exists = await roleRepository.ExistsAsync(
                    new GetRoleByNameExcludingCurrentSpecification(
                        command.Model.Name,
                        command.Id,
                        command.ShopId),
                    ct);

                if (exists)
                    throw new ConflictException(ValidationErrorMessages.Role.RoleExistsErrorMessage);
            });

        // Permission existence batch validation
        RuleFor(x => x.Model.PermissionIds)
            .CustomAsync(async (ids, context, ct) =>
            {
                var distinctIds = ids.Distinct().ToArray();

                var existingPermissionIds = await permissionRepository
                    .GetIdsBySpecAsync(
                        new GetValidPermissionsSpecification(distinctIds),
                        ct);

                if (existingPermissionIds.Count() != distinctIds.Length)
                    throw new BadRequestException(ValidationErrorMessages.Role.PermissionsDontExistErrorMessage);
            });

        RuleFor(x => x.Model.PermissionIds)
            .Custom((ids, context) =>
            {
                var systemPermissionIds = PermissionRegistry.All
                    .Values
                    .Where(p => p.IsSystemPermission)
                    .Select(p => p.Id);

                if (ids.Intersect(systemPermissionIds).Any())
                    throw new ForbiddenException(ValidationErrorMessages.Role.CannotAssignSystemPermissionErrorMessage);
            });
    }
}
