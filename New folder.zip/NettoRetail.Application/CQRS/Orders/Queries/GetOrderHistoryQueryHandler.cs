﻿using MapsterMapper;
using MediatR;
using NettoRetail.Application.Exceptions;
using NettoRetail.Application.Models.Response.Order;
using NettoRetail.DataAccess.Specifications.Order;
using NettoRetail.Shared.Interfaces.Repositories;

namespace NettoRetail.Application.CQRS.Orders.Queries;

public record GetOrderHistoryQuery(Guid CustomerId, int ShopId) : IRequest<IEnumerable<OrderHistoryResponse>>;

public class GetOrderHistoryQueryHandler(IOrderRepository orderRepository, IMapper mapper)
    : IRequestHandler<GetOrderHistoryQuery, IEnumerable<OrderHistoryResponse>>
{
    public async Task<IEnumerable<OrderHistoryResponse>> Handle(GetOrderHistoryQuery request, CancellationToken cancellationToken)
    {
        var ordersByCustomerIdShopId = new GetOrderByCustomerIdAndShopIdSpecification(request.CustomerId, request.ShopId);
        var order = await orderRepository.GetManyBySpecAsync(ordersByCustomerIdShopId, cancellationToken)
            ?? throw new NotFoundException("There is no such order.");

        var response = mapper.Map<IEnumerable<OrderHistoryResponse>>(order);

        return response;
    }
}
