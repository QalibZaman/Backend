﻿using MediatR;
using NettoRetail.Application.Exceptions;
using NettoRetail.Application.Interfaces;
using NettoRetail.DataAccess.Specifications.Feedback;
using NettoRetail.Domain.Enums;
using NettoRetail.Infrastructure.Interfaces;
using NettoRetail.Shared.Interfaces.Repositories;

namespace NettoRetail.Application.CQRS.Feedbacks.Commands;

public record RejectFeedbackCommand(Guid Id, string Reason) : IRequest;

public class RejectFeedbackCommandHandler(
    IFeedbackRepository feedbackRepository,
    IEmailSender emailSender,
    IEmailBuilderService emailBuilderService)
    : IRequestHandler<RejectFeedbackCommand>
{
    public async Task Handle(RejectFeedbackCommand request, CancellationToken cancellationToken)
    {
        var reason = FeedbackRejectionReason.NormalizeOrThrow(request.Reason);
        var specification = new GetFeedbackByIdSpecification(request.Id);
        specification.AddInclude(f => f.Account);
        var feedback = await feedbackRepository.GetAsync(specification, cancellationToken)
                      ?? throw new NotFoundException("Feedback not found.");

        if (feedback.Status != FeedbackStatusEnum.Pending)
            throw new BadRequestException("Only pending feedbacks can be rejected.");
        feedback.Status = FeedbackStatusEnum.Rejected;
        feedback.RejectionReason = reason;
        feedback.IsVisible = false;
        await feedbackRepository.UpdateAsync(feedback, cancellationToken);

        //SmtpClient not working
        var email = feedback.Account?.Email;
        if (string.IsNullOrWhiteSpace(email))
            return;

        var bulkEmailModel = await emailBuilderService.BuildFeedbackRejectedEmailsAsync([email], reason);
        await emailSender.SendBulkAsync(bulkEmailModel);
    }
}
